#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<string.h>

#define PORT 6666
#define SIZE 32

int main(int argc, char *argv[])   /*  TCP CLIENT */
{
	char i = 1, *rbuff;
	int sockfd;
	long addr;
	addr = inet_addr(argv[1]);


	typedef struct sockaddr SOCK;
	typedef struct sockaddr_in SOCK_IN;
	SOCK_IN	cli_obj;

	cli_obj.sin_family	=	AF_INET;
	cli_obj.sin_port	=	htons(PORT);
	cli_obj.sin_addr.s_addr	=	addr;

	if (NULL == (rbuff = (char *)malloc(sizeof(char) * SIZE))) {
		perror("malloc");
		exit(1);
	}

	if (-1 == (sockfd = socket(AF_INET, SOCK_STREAM, 0))) {
		perror("Socket");
		exit(-1);
	}
	
	if(-1==connect(sockfd, (SOCK *)&cli_obj, sizeof(SOCK))) {
		perror("Connect");
		exit(-1);
  	}
   	printf("Success\n");
	
	while(i!='0') {
		printf(">");
		if(-1==recv(sockfd,rbuff, SIZE, 0)) {
			perror("Recv");
			exit(-1);
		}
		printf("%s\n",rbuff);
		i = *rbuff;
	}
	close(sockfd);
}
