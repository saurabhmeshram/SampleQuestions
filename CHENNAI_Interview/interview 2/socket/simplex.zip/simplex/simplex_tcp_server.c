#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<string.h>

#define PORT 6666
#define BACKLOG 3
#define SIZE 32

int main(int argc, char *argv[])	/*  TCP SERVER  */
{	

	char *wbuff, i = 1;
	
	long addr;
	addr = inet_addr(argv[1]);
	
	typedef struct sockaddr SOCK;
	typedef struct sockaddr_in SOCK_IN;
	
	SOCK_IN srv_obj, cli_obj;
	int sockfd, newfd, len=0;
	
	srv_obj.sin_family	=	AF_INET;
	srv_obj.sin_port	=	htons(PORT);
	srv_obj.sin_addr.s_addr = 	addr;

	if (NULL == (wbuff = (char *)malloc(sizeof(char) * SIZE))) {
		perror("malloc");
		exit(-1);
	}
	
	if (-1 == (sockfd = socket(AF_INET, SOCK_STREAM, 0))) {
		perror("Socket error");
		exit(-1);
	}

	if(-1 == bind(sockfd, (SOCK *)&srv_obj, sizeof(SOCK))) {
		perror("Bind error");
		exit(-1);
	}

	if(-1 == listen(sockfd, BACKLOG)) {
		perror("Listen error");
		exit(-1);
	}
	printf("Waiting for connection\n");

	len = sizeof(SOCK);
	
	if(-1 == (newfd = accept(sockfd, (SOCK *)&cli_obj, &len))) {
		perror("Accept error");
		exit(-1);
	}

	printf("Connection Established....\n");
	printf("Radio service (simplex)\n");
	while (i != '0') {		
		printf(">");
		fgets(wbuff, SIZE, stdin);
		wbuff[strlen(wbuff)-1]=0;
		i=*wbuff;
		if(-1 == send(newfd, wbuff, SIZE, 0)) {
			perror("write");
			exit(-1);
		}
	}
	close(sockfd);
	close(newfd);
}
